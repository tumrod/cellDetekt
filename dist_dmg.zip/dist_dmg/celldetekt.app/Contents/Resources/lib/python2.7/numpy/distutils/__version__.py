from __future__ import division, absolute_import, print_function

major = 0
minor = 4
micro = 0
version = '%(major)d.%(minor)d.%(micro)d' % (locals())
